<?php
$lang['rights_message'] = 'Invision &copy; 2017. All rights reserved.';
