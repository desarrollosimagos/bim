<?php
$lang['placeholder_name'] = 'User';
$lang['placeholder_password'] = 'Password';
$lang['button_value'] = 'Login';
