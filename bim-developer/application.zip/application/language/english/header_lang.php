<?php
$lang['top_bar_login'] = 'Log in';
$lang['top_bar_logout'] = 'Log out';
$lang['menu_bar_menu1'] = 'Start';
$lang['menu_bar_menu2'] = 'Possibilities';
$lang['menu_bar_menu3'] = 'Investments';
$lang['menu_bar_menu4'] = 'Contacts';
$lang['menu_bar_menu5'] = 'Summary';
$lang['language_menu1'] = 'English';
$lang['language_menu2'] = 'Spanish';
