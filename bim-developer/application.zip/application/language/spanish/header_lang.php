<?php
$lang['top_bar_login'] = 'Iniciar Sesión';
$lang['top_bar_logout'] = 'Cerrar Sesión';
$lang['menu_bar_menu1'] = 'Inicio';
$lang['menu_bar_menu2'] = 'Posibilidades';
$lang['menu_bar_menu3'] = 'Inversiones';
$lang['menu_bar_menu4'] = 'Contactos';
$lang['menu_bar_menu5'] = 'Resumen';
$lang['language_menu1'] = 'Inglés';
$lang['language_menu2'] = 'Español';
