<?php
$lang['rights_message'] = 'Invision &copy; 2017. Todos los derechos reservados.';
