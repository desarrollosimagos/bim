<?php
$lang['placeholder_name'] = 'Usuario';
$lang['placeholder_password'] = 'Contraseña';
$lang['button_value'] = 'Iniciar sesión';
