		<div class="footer">
			<div class="pull-right">
			<!-- 10GB of <strong>250GB</strong> Free.-->
			</div>
			<div><strong></strong> <?php echo $this->lang->line('rights_message'); ?></div>
		</div>
	</div>
</div>
</body>
<script src="<?php echo assets_url('script/menu.js');?>"></script>
</html>

