<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Transacción </h2>
        <ol class="breadcrumb">
            <li>
                <a href="index.html">Inicio</a>
            </li>
            
            <li>
                <a href="<?php echo base_url() ?>transactions">Transacciones</a>
            </li>
           
            <li class="active">
                <strong>Editar Transacción</strong>
            </li>
        </ol>
    </div>
</div>

<!-- Campos ocultos que almacenan el tipo de moneda de la cuenta del usuario logueado -->
<input type="hidden" id="iso_currency_user" value="<?php echo $this->session->userdata('logged_in')['coin_iso']; ?>">
<input type="hidden" id="symbol_currency_user" value="<?php echo $this->session->userdata('logged_in')['coin_symbol']; ?>">

<!-- Campos ocultos que almacenan los nombres del menú y el submenú de la vista actual -->
<input type="hidden" id="ident" value="<?php echo $ident; ?>">
<input type="hidden" id="ident_sub" value="<?php echo $ident_sub; ?>">

<div class="wrapper wrapper-content animated fadeInRight">
	<div class="row">
        <div class="col-lg-12">
			<div class="ibox float-e-margins">
				<div class="ibox-title">
					<h5>Editar Transacción</h5>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<label style="color:red;">
						(Capital aprobado: <span id="span_capital_aprobado"></span>
						<?php echo $this->session->userdata('logged_in')['coin_symbol']; ?>)
						
						</label>
				</div>
				<div class="ibox-content">
					<form id="form_transactions" method="post" accept-charset="utf-8" class="form-horizontal">
						<div class="form-group">
							<label class="col-sm-2 control-label" >Tipo *</label>
							<div class="col-sm-10">
								<select class="form-control m-b" name="type" id="type">
									<option value="deposit">Depósito</option>
									<option value="expense">Gasto</option>
									<!--<option value="internal">Interno</option>-->
									<option value="invest">Inversión</option>
									<option value="profit">Ganancia</option>
									<option value="sell">Venta</option>
									<option value="transfer">Transferencia</option>
									<option value="withdraw">Retiro</option>
								</select>
							</div>
						</div>
						<!-- Si el usuario es administrador, entonces puede elegir el usuario -->
						<?php if($this->session->userdata('logged_in')['id'] == 1){ ?>
						<div class="form-group">
							<label class="col-sm-2 control-label" >Usuario *</label>
							<div class="col-sm-10">
								<select class="form-control m-b" name="user_id" id="user_id">
									<option value="0">Seleccione</option>
									<?php foreach($usuarios as $usuario){?>
									<option value="<?php echo $usuario->id; ?>"><?php echo $usuario->username; ?></option>
									<?php } ?>
								</select>
							</div>
						</div>
						<?php } ?>
						<!-- Fin validación -->
						<div class="form-group">
							<label class="col-sm-2 control-label" >Proyecto *</label>
							<div class="col-sm-10">
								<select class="form-control m-b" name="project_id" id="project_id">
									<option value="0">Seleccione</option>
									<?php foreach($projects as $project){?>
									<option value="<?php echo $project->id; ?>"><?php echo $project->name; ?></option>
									<?php } ?>
								</select>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-2 control-label" >Cuenta *</label>
							<div class="col-sm-10">
								<select class="form-control m-b" name="account_id" id="account_id">
									<option value="0">Seleccione</option>
									<?php foreach($accounts as $cuenta){?>
									<option value="<?php echo $cuenta->id; ?>"><?php echo $cuenta->alias." - ".$cuenta->number." - ".$cuenta->coin_avr; ?></option>
									<?php } ?>
								</select>
							</div>
						</div>
						<div class="form-group"><label class="col-sm-2 control-label" >Fecha</label>
							<div class="col-sm-10">
								<?php 
								$fecha = $editar[0]->date;
								$fecha = explode(" ", $fecha);
								$fecha = explode("-", $fecha[0]);
								$fecha = $fecha[2]."/".$fecha[1]."/".$fecha[0];
								
								$hora = $editar[0]->date;
								$hora = explode(" ", $hora);
								$hora = $hora[1];
								
								$fecha = $fecha." ".$hora;
								?>
								<input type="text" class="form-control" name="date" maxlength="19" id="date" value="<?php echo $fecha; ?>"/>
							</div>
						</div>
						<div class="form-group"><label class="col-sm-2 control-label" >Descripción</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" name="description" maxlength="250" id="description" value="<?php echo $editar[0]->description; ?>"/>
							</div>
						</div>
						<div class="form-group"><label class="col-sm-2 control-label" >Referencia</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" name="reference" maxlength="100" id="reference" value="<?php echo $editar[0]->reference; ?>"/>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-2 control-label" >Observaciones</label>
							<div class="col-sm-10">
								<textarea class="form-control" name="observation" maxlength="250" id="observation"><?php echo $editar[0]->observation; ?></textarea>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-2 control-label" >Monto *</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" name="amount" id="amount" value="<?php echo $editar[0]->amount ?>" onkeypress="return valida_monto(event)">
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-2 control-label">Documento</label>
							<div class="col-sm-4">
								<input type="file" class="form-control" name="document[]" id="document" onChange="valida_tipo($(this))">
							</div>
							<div class="col-sm-6">
								<?php if($editar[0]->document != ''){ ?>
									<?php $ext = explode(".", $editar[0]->document); $ext = $ext[1]; ?>
									<?php if($ext == "pdf"){ ?>
									<a target="_blank" href="<?php echo base_url(); ?>assets/docs_trans/<?php echo $editar[0]->document; ?>"><?php echo $editar[0]->document; ?></a>
									<?php }else{ ?>
									<img id="imgSalida" style="height:150px;width:150px;" class="img-circle" src="<?php echo base_url(); ?>assets/docs_trans/<?php echo $editar[0]->document; ?>">
									<?php } ?>
								<?php }else{ ?>
								<img id="imgSalida" style="height:150px;width:150px;" class="img-circle" src="<?php echo base_url(); ?>assets/img/users/usuario.jpg">
								<?php } ?>
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-4 col-sm-offset-2">
								 <input id="id_tipo" type="hidden" value="<?php echo $editar[0]->type ?>"/>
								 <input id="id_user" type="hidden" value="<?php echo $editar[0]->user_id ?>"/>
								 <input id="id_proyecto" type="hidden" value="<?php echo $editar[0]->project_id ?>"/>
								 <input id="id_cuenta" type="hidden" value="<?php echo $editar[0]->account_id ?>"/>
								 <input id="id_status" type="hidden" value="<?php echo $editar[0]->status ?>"/>
								 <input id="id_document" type="hidden" value="<?php echo $editar[0]->document; ?>"/>
								 <input id="usuario" type="hidden" value="<?php echo $this->session->userdata('logged_in')['id']; ?>"/>
								 <input class="form-control"  type='hidden' id="id" name="id" value="<?php echo $id ?>"/>
								<button class="btn btn-white" id="volver" type="button">Volver</button>
								<button class="btn btn-primary" id="edit" type="submit">Guardar</button>
							</div>
						</div>
					</form>
				</div>
			</div>
        </div>
    </div>
</div>
<script>
$(document).ready(function(){

    $('input').on({
        keypress: function () {
            $(this).parent('div').removeClass('has-error');
        }
    });

    $('#volver').click(function () {
        url = '<?php echo base_url() ?>transactions/';
        window.location = url;
    });
    
    //~ $('#date').datepicker({
        //~ format: "dd/mm/yyyy",
        //~ language: "es",
        //~ autoclose: true,
        //~ endDate: 'today'
    //~ })
    
    $.datetimepicker.setLocale('es');
	$('#date').datetimepicker({
	  format:'d/m/Y H:i:s'
	});
    
    // Función para la pre-visualización de la imagen a cargar
	$(function() {
		$('#document').change(function(e) {
			addImage(e); 
		});

		function addImage(e){
			var file = e.target.files[0],
			imageType = /image.*/;

			if (!file.type.match(imageType))
			return;

			var reader = new FileReader();
			reader.onload = fileOnload;
			reader.readAsDataURL(file);
		}
	  
		function fileOnload(e) {
			var result=e.target.result;
			$('#imgSalida').attr("src",result);
		}
	});
    
    //~ $("#amount").numeric("-."); // Sólo permite valores numéricos
    
    var capital_pendiente = 0;
	var capital_aprobado = 0;
    // Proceso de conversión de monedas de los distintos montos a la moneda del usuario logueado (captura del equivalente a 1 dólar en las distintas monedas)
    $.post('https://openexchangerates.org/api/latest.json?app_id=65148900f9c2443ab8918accd8c51664', function (coins) {
		
		var currency_user = coins['rates'][$("#iso_currency_user").val()];  // Tipo de moneda del usuario logueado
		
		// Proceso de cálculo de capital aprobado y pendiente
		$.post('<?php echo base_url(); ?>dashboard/fondos_json', function (fondos) {
			
			$.each(fondos, function (i) {
				
				// Conversión de cada monto a dólares
				var currency = fondos[i]['coin_avr'];  // Tipo de moneda de la transacción
				var trans_usd = parseFloat(fondos[i]['amount'])/coins['rates'][currency];
				
				// Sumamos o restamos dependiendo del tipo de transacción (ingreso/egreso)
				if(fondos[i]['status'] == 'waiting'){
					if(fondos[i]['type'] == 'deposit'){
						capital_pendiente += trans_usd;
					}else{
						capital_pendiente -= trans_usd;
					}
				}
				if(fondos[i]['status'] == 'approved'){
					if(fondos[i]['type'] == 'deposit'){
						capital_aprobado += trans_usd;
					}else{
						capital_aprobado -= trans_usd;
					}
				}
			});
			
			capital_aprobado = (capital_aprobado*currency_user).toFixed(2);
			
			capital_pendiente = (capital_pendiente*currency_user).toFixed(2);
			
			$("#span_capital_aprobado").text(capital_aprobado);
			
		}, 'json');
		
	}, 'json');
	
	
	$("#project_id").select2('val', $("#id_proyecto").val());
	$("#account_id").select2('val', $("#id_cuenta").val());
	if($("#user_id").val() !== undefined){
		$("#user_id").select2('val', $("#id_user").val());
	}
	$("#type").select2('val', $("#id_tipo").val());
	
	
	// Proceso de validación del registro
    $("#edit").click(function (e) {

        e.preventDefault();  // Para evitar que se envíe por defecto

        /*if ($('#user_id').val() == "0") {
			
			swal("Disculpe,", "para continuar debe seleccionar el usuario");
			$('#user_id').focus();
			$('#user_id').parent('div').addClass('has-error');
			
        } else if ($('#project_id').val() == "0") {
			
			swal("Disculpe,", "para continuar debe seleccionar el proyecto");
			$('#project_id').focus();
			$('#project_id').parent('div').addClass('has-error');
			
        } else*/ if ($('#account_id').val() == "0") {
			
			swal("Disculpe,", "para continuar debe seleccionar la cuenta");
			$('#account_id').focus();
			$('#account_id').parent('div').addClass('has-error');
			
        } else if ($('#date').val().trim() === ""){
			
			swal("Disculpe,", "para continuar debe ingresar la fecha");
			$('#date').focus();
			$('#date').parent('div').addClass('has-error');
			
		} else if ($('#amount').val().trim() === ""){
			
			swal("Disculpe,", "para continuar debe ingresar el monto");
			$('#amount').focus();
			$('#amount').parent('div').addClass('has-error');
			
		} else {
			
			var monto_convertido;
	
			$.post('https://openexchangerates.org/api/latest.json?app_id=65148900f9c2443ab8918accd8c51664', function (coins) {
		
				var currency_user = coins['rates'][$("#iso_currency_user").val()];  // Tipo de moneda del usuario logueado
				
				// Conversión de cada monto a dólares
				var currency = $("#account_id").find('option').filter(':selected').text();  // Tipo de moneda de la cuenta
				currency = currency.split(' - ');
				currency = currency[2];
				//~ alert(currency);
				var trans_usd = parseFloat($('#amount').val().trim())/coins['rates'][currency];
				//~ alert(trans_usd);
				
				monto_convertido = trans_usd;
					
				monto_convertido = (monto_convertido*currency_user).toFixed(2);
				
			}, 'json').done(function() {
				
				//~ alert("Monto convertido: " + monto_convertido);
				//~ alert("Capital aprobado: " + capital_aprobado);
				
				if(monto_convertido > capital_aprobado && $('#type').val().trim() == 'withdraw' && $("#usuario").val().trim() != 1){
					
					alert("El monto a retirar no puede ser superior al capital aprobado");
					
				}else{
					
					//~ $.post('<?php echo base_url(); ?>CFondoPersonal/update', $('#form_transactions').serialize(), function (response) {
						//~ if (response['response'] == 'error') {
							//~ swal("Disculpe,", "El registro no pudo ser guardado, por favor consulte a su administrador...");
						//~ }else{
							//~ swal({ 
								//~ title: "Registro",
								 //~ text: "Guardado con exito",
								  //~ type: "success" 
								//~ },
							//~ function(){
							  //~ window.location.href = '<?php echo base_url(); ?>transactions';
							//~ });
						//~ }
					//~ }, 'json');
					
					var formData = new FormData(document.getElementById("form_transactions"));  // Forma de capturar todos los datos del formulario
			
					$.ajax({
						//~ method: "POST",
						type: "post",
						dataType: "json",
						url: '<?php echo base_url(); ?>CFondoPersonal/update',
						data: formData,
						cache: false,
						contentType: false,
						processData: false
					})
					.done(function(response) {
						if(response.error){
							console.log(response.error);
						} else {
							if (response['response'] == 'error') {
							
								swal("Disculpe,", "El registro no pudo ser guardado, por favor consulte a su administrador...");
								
							}else if (response['response'] == 'error2') {
								
								swal("Disculpe,", "ha ocurrido un error al guardar el documento");
								
							}else{
								
								swal({ 
									title: "Registro",
									 text: "Guardado con exito",
									  type: "success" 
									},
								function(){
								  window.location.href = '<?php echo base_url(); ?>transactions';
								});
								
							}
							
						}				
					}).fail(function() {
						console.log("error ajax");
					});
					
				}
				
			});
            
        }
        
    });
    
});

function valida_monto(e){
    tecla = (document.all) ? e.keyCode : e.which;

    //Tecla de retroceso para borrar, siempre la permite
    if (tecla==8){
        return true;
    }
        
    // Patron de entrada, en este caso solo acepta numeros
    patron =/[0-9-.-]/;
    tecla_final = String.fromCharCode(tecla);
    return patron.test(tecla_final);
}


// Validamos que los archivos sean de tipo .jpg, jpeg, png o pdf
function valida_tipo(input) {
	
	var max_size = '';
	var archivo = input.val();
	
	var ext = archivo.split(".");
	ext = ext[1];
	
	if (ext != 'jpg' && ext != 'jpeg' && ext != 'png' && ext != 'pdf'){
		swal("Disculpe,", "sólo se admiten archivos .jpg, .jpeg, .png y .pdf");
		input.val('');
		input.parent('div').addClass('has-error');
	}else{
		input.parent('div').removeClass('has-error');
	}
}

</script>
