<?php
$this->load->model('MCuentas');
?>
<style>
.ibox-content {
    background-color: #ffffff;
    color: inherit;
    padding: 15px 20px 20px 20px;
    border-color: #e7eaec;
    border-image: none;
    border-style: solid solid solid;
    border-width: 1px 1px 1px 1px;
}
</style>

<!-- FooTable -->
<!--<link href="<?php echo assets_url('css/plugins/footable/footable.bootstrap.css');?>" rel="stylesheet">-->
<link href="<?php echo assets_url('css/plugins/footable/footable.core.css');?>" rel="stylesheet">

<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2><?php echo $ver[0]->alias; ?></h2>
        <ol class="breadcrumb">
            <li>
                <a href="<?php echo base_url() ?>home">Home</a>
            </li>
            
            <li>
                <a href="<?php echo base_url() ?>accounts">Cuentas</a>
            </li>
           
            <li class="active">
                <strong><?php echo $ver[0]->alias; ?></strong>
            </li>
        </ol>
    </div>
</div>

<!-- Campos ocultos que almacenan los nombres del menú y el submenú de la vista actual -->
<input type="hidden" id="ident" value="<?php echo $ident; ?>">
<input type="hidden" id="ident_sub" value="<?php echo $ident_sub; ?>">

<div class="wrapper wrapper-content animated fadeInUp">
	
	<!-- Cuerpo de la sección de cintillo de montos -->
	<div class="row">
		<div class="col-lg-12">
			<div class="contact-box">
				
				<div class="contact-box-footer" style="border-top:0px;">
					<div>
						<?php 
						$capital_disponible_total = 0;
						$capital_disponible_parcial = 0;
						$depósito_pendiente = 0;
						$capital_diferido = 0;
						
						// Cálculo de los capitales disponibles
						foreach($find_transactions as $transact) {
							if($transact->status == 'approved'){ $capital_disponible_total += $transact->amount; }
							$relations = $this->MCuentas->buscar_transaction_relation($transact->id);
							if($transact->type != "invest" && $transact->type != "sell" && $transact->status == 'approved'){
								if(count($relations) == 0){
									$capital_disponible_parcial += $transact->amount;
								}
								if(count($relations) > 0 && $relations[0]->type != "distribute"){
									$capital_disponible_parcial += $transact->amount;
								}
							}
						}
						//~ foreach($find_transactions_project as $transact_project) {
							//~ if($transact_project->status == 'approved'){ $capital_disponible_total += $transact_project->monto; }
							//~ $relations = $this->MCuentas->buscar_project_transaction_relation($transact_project->id);
							//~ if(count($relations) == 0){
								//~ if($transact_project->type == "profit" || $transact_project->type == "expense"){
									//~ if($transact_project->status == 'approved'){
										//~ $capital_disponible_parcial += $transact_project->monto;
									//~ }
								//~ }
							//~ }
						//~ }
						?>
						<div class="col-md-6 forum-info">
							<span class="views-number" id="span_retornado">
								<?php echo $capital_disponible_total; ?>
							</span>
							<div>
								<small>Capital disponible total</small>
							</div>
						</div>
						<div class="col-md-6 forum-info">
							<span class="views-number" id="span_aprobado">
								<?php echo $capital_disponible_parcial; ?>
							</span>
							<div>
								<small>Capital disponible parcial</small>
							</div>
						</div>
						<!--<div class="col-md-3 forum-info">
							<span class="views-number" id="span_ingreso_pendiente">
								<?php echo $depósito_pendiente; ?>
							</span>
							<div>
								<small>Depósito Pendiente</small>
							</div>
						</div>
						<div class="col-md-3 forum-info">
							<span class="views-number" id="span_egreso_pendiente">
								<?php echo $capital_diferido; ?>
							</span>
							<div>
								<small>Capital Diferido</small>
							</div>
						</div>-->
					</div>
					<br>
					<br>
				</div>
			</div>
		</div>
	</div>
	<!-- Cierre del cuerpo de la sección de cintillo de montos -->

	<!-- Cuerpo de la sección de transacciones -->
	<div class="ibox float-e-margins">
		<div class="ibox-title">
			<h5>Transactions</h5>

			<div class="ibox-tools">
				<a class="collapse-link">
					<i class="fa fa-chevron-up"></i>
				</a>
				<!--<a class="dropdown-toggle" data-toggle="dropdown" href="#">
					<i class="fa fa-wrench"></i>
				</a>
				<ul class="dropdown-menu dropdown-user">
					<li><a href="#">Config option 1</a>
					</li>
					<li><a href="#">Config option 2</a>
					</li>
				</ul>-->
				<a class="close-link">
					<i class="fa fa-times"></i>
				</a>
			</div>
		</div>
		<div class="ibox-content">
			
			<div class="col-sm-4 col-md-offset-8">
				<div class="input-group">
					<input type="text" placeholder="Search in table" class="input-sm form-control" id="filter1">
					<span class="input-group-btn">
						<button type="button" class="btn btn-sm btn-primary"> Go!</button>
					</span>
				</div>
			</div>
			
			<!--<input type="text" class="form-control input-sm m-b-xs"  placeholder="">-->
			
			<table class="footable table table-stripped" data-page-size="50" data-filter=#filter1>
				<thead>
					<tr>
						<th data-hide="phone,tablet">Id</th>
						<th data-hide="phone,tablet">Fecha</th>
						<th>Usuario(nombre)</th>
						<th data-hide="phone,tablet">Tipo</th>
						<th data-hide="phone,tablet">Descripción</th>
						<th>Monto</th>
						<th data-hide="phone,tablet">Proyecto</th>
						<th data-hide="phone,tablet">Estatus</th>
					</tr>
				</thead>
				<tbody>
					<?php $i = 1; ?>
					<?php $total = 0; ?>
					<!-- Transacciones de la tabla 'transactions' -->
					<?php foreach ($find_transactions as $transact) { ?>
						<?php $background_color = "";?>
						<?php $relations = $this->MCuentas->buscar_transaction_relation($transact->id); ?>
						<?php if($transact->type != "invest" && $transact->type != "sell"){ ?>
							<?php if(count($relations) == 0){ ?>
							<?php $background_color = "background-color: #0DD9E9;";?>
							<?php } ?>
							<?php if(count($relations) > 0 && $relations[0]->type != "distribute"){ ?>
							<?php $background_color = "background-color: #0DD9E9;";?>
							<?php } ?>
						<?php } ?>
						<tr style="text-align: center;<?php echo $background_color; ?>">
							<td>
								<?php echo $transact->id; ?>
							</td>
							<td>
								<?php echo $transact->date; echo count($relations); ?>
							</td>
							<td>
								<?php echo $transact->name_user; ?>
							</td>
							<td>
								<?php echo $transact->type; ?>
							</td>
							<td>
								<?php echo $transact->description; ?>
							</td>
							<td>
								<?php echo $transact->amount."  ".$transact->coin_avr; ?>
							</td>
							<td>
								<?php echo $transact->name_project; ?>
							</td>
							<td>
								<?php
								if($transact->status == "approved"){
									echo "<i class='fa fa-check text-navy'></i>";
								}else if($transact->status == "waiting"){
									echo "<i class='fa fa-check text-warning'></i>";
								}else if($transact->status == "denied"){
									echo "<i class='fa fa-times text-danger'></i>";
								}else{
									echo "";
								}
								?>
							</td>
						</tr>
						<?php $i++ ?>
						<?php if($transact->status == 'approved'){ $total += $transact->amount; } ?>
					<?php } ?>
					<!-- Fin de Transacciones de la tabla 'transactions' -->
					
					<!-- Transacciones de la tabla 'project_transactions' -->
					<?php //foreach ($find_transactions_project as $transact_project) { ?>
						<?php //$background_color = "";?>
						<?php //$relations = $this->MCuentas->buscar_project_transaction_relation($transact_project->id); ?>
						<?php //if(count($relations) == 0){ ?>
							<?php //if($transact_project->type == "profit" || $transact_project->type == "expense"){ ?>
							<?php //$background_color = "background-color: #0DD9E9;";?>
							<?php //} ?>
						<?php //} ?>
						<!--<tr style="text-align: center;<?php //echo $background_color; ?>">
							<td>
								<?php //echo $transact_project->date; ?>
							</td>
							<td>
								<?php //echo $transact_project->name_user; ?>
							</td>
							<td>
								<?php //echo $transact_project->type; ?>
							</td>
							<td>
								<?php //echo $transact_project->description; ?>
							</td>
							<td>
								<?php //echo $transact_project->monto."  ".$transact_project->coin_avr; ?>
							</td>
							<td>
								<?php //echo $transact_project->name_project; ?>
							</td>
							<td>
								<?php
								//~ if($transact_project->status == "approved"){
									//~ echo "<i class='fa fa-check text-navy'></i>";
								//~ }else if($transact_project->status == "waiting"){
									//~ echo "<i class='fa fa-check text-warning'></i>";
								//~ }else if($transact_project->status == "denied"){
									//~ echo "<i class='fa fa-times text-danger'></i>";
								//~ }else{
									//~ echo "";
								//~ }
								?>
							</td>
						</tr>-->
						<?php //$i++ ?>
						<?php //if($transact_project->status == 'approved'){ $total += $transact_project->monto; } ?>
					<?php //} ?>
					<!-- Fin de Transacciones de la tabla 'project_transactions' -->
					
				</tbody>
				<tfoot>
					<tr>
						<td class='text-center' colspan='6'>
							<ul class='pagination'></ul>
						</td>
						<td class='text-right' colspan='1'>
							<span style="font-weight:bold;">Total: <?php echo $total."  ".$ver[0]->coin_avr; ?></span>
						</td>
					</tr>
				</tfoot>
			</table>
			
		</div>
		
	</div>
	<!-- Cierre del cuerpo de la sección de transacciones -->

</div>

<!-- FooTable -->
<!--<script src="<?php echo assets_url('js/plugins/footable/footable.js');?>"></script>-->
<script src="<?php echo assets_url('js/plugins/footable/footable.all.min.js');?>"></script>

<!-- Peity -->
<script src="<?php echo assets_url('js/plugins/peity/jquery.peity.min.js');?>"></script>
<script src="<?php echo assets_url('js/demo/peity-demo.js');?>"></script>

<!-- Flot -->
<script src="<?php echo assets_url('js/plugins/flot/jquery.flot.js');?>"></script>
<script src="<?php echo assets_url('js/plugins/flot/jquery.flot.pie.js');?>"></script>

<script>
$(document).ready(function(){
	
	$('.footable').footable();  // Aplicamos el plugin footable
	
});
</script>
